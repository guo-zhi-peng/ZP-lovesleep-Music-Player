<script setup>
import { useTheme } from "@/hooks/useTheme";
import defaultComm from "@/layouts/default.vue";
// 使用主题
useTheme()
</script>
<template>
	<defaultComm />
</template>

