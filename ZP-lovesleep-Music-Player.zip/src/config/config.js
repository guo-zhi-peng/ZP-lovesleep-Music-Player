// * 默认主题颜色
export const DEFAULT_PRIMARY = "#409EFF";
